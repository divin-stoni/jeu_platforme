# C'ÉTAIT ÉCRIT : cartes et jetons v0.6 (périmètre IA-2)

## À imprimer
`CARTES_v0_6_impression.pdf` (27 pages A4, à 100 %, sans mise à l'échelle) :
- p01 à p24 : recto/verso en alternance (impair = face, pair = dos). Imprimer en recto-verso, retournement sur le GRAND côté.
- p25 et p26 : jetons (recto seul, papier épais).
- p27 : parchemins de prophétie (photocopier selon besoin).
- p08 : le dos des cartes Stratège n'est imprimé que sur la 1re rangée (3 cartes).

Mise en page : gouttière de 3 mm entre cartes, marge de couleur de 1,5 mm derrière chaque carte, repères de coupe dans les marges, polices incorporées (Carlito et Caladea, licences libres).
Limite : ce n'est pas un vrai fond perdu. L'illustration s'arrête au trait de la carte, seule la couleur de fond déborde.

## Corrections de texte (contrat v0.6)
- Rediffusion : une seule manche (D10).
- Carte du tronc : portes, deux duels, recul de 3, victoire en atteignant ou dépassant la 33 (D3, D8, D11).
- La Table : alternance A, B, A, B (D9).
- Fausse mort : pas de visée, pas de prophétie si elle tient la Plume (A11).
- Maître : « sauf celle d'avant » (Mémoire). Ajout de ma part, à confirmer.

## Jetons
- Reliques-Bouteilles : flacon original sans texte (`flacon_original.svg`, réutilisable pour la case 33 du plateau).
- Marqueur de manche : flèche au lieu du « I ».

## Trou de règle à trancher (A13)
E23 « Mise à jour disponible » : avec l'alternance A/B, quel tas pour le nouveau Genre ? Proposition : celui qui vient dans l'alternance.

## Non fait
- `check_coherence.py` non lancé (fichier absent de mon côté).
- Parchemins et espacement des Armures non retouchés.
- Aucune impression réelle testée : alignement recto-verso vérifié seulement sur les rendus.
