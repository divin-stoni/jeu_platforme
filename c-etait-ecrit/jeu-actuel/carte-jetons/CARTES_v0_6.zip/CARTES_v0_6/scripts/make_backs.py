import pathlib
from lxml import etree
ns='{http://www.w3.org/2000/svg}'
SRC=pathlib.Path('../CARTE/carte-recto-verso'); OUT=pathlib.Path('out/backs')
M={'B02_dos_heros':'dos_heros_texte','B04_dos_actions':'dos_actions_p2_texte','B06_dos_actions':'dos_actions_p2_texte','B08_dos_actions':'dos_actions_p2_texte',
 'B10_dos_evenements_acte1':'p02_evenements_acte1_dos_texte','B12_dos_evenements_acte2':'p04_evenements_acte2_dos_texte','B14_dos_evenements_acte3':'p06_evenements_acte3_dos_texte',
 'B16_dos_rebondissements_R01-R09':'p08_rebondissements_R01-R09_dos_texte','B18_dos_rebondissements_R10-R16':'p10_rebondissements_R10-R16_dos_texte',
 'B20_dos_genres':'p12_genres_dos_texte','B22_dos_dossier_gerard':'p14_dossier_gerard_dos_texte','B24_dos_proces_verbal':'p16_proces_verbal_dos_texte'}
for out,src in M.items():
    t=etree.parse(str(SRC/(src+'.svg'))); r=t.getroot()
    for e in list(r.iter(ns+'text')):
        s=''.join(e.itertext()).strip()
        if s.startswith(('Dos des cartes','Dos ')) and len(s)>40: e.getparent().remove(e); print(out,'pied retiré:',s[:50])
    t.write(str(OUT/(out+'.svg')),xml_declaration=True,encoding='utf-8')
