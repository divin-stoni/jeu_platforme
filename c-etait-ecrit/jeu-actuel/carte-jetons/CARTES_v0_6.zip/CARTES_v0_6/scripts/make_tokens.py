# Jetons v0.6 : flacon original (P03), marqueur de manche sans numéro (P14), pieds de page retirés.
import pathlib
from lxml import etree
SVG='http://www.w3.org/2000/svg'; ns='{%s}'%SVG
SRC=pathlib.Path('../CARTE/carte-recto-verso'); OUT=pathlib.Path('out/fronts'); OUT.mkdir(parents=True,exist_ok=True)
txt=lambda e:''.join(e.itertext()).strip()

FLACON='''<g xmlns="http://www.w3.org/2000/svg" transform="translate({cx},{cy})">
 <circle r="22" fill="#ffe9a8" stroke="#1d1b3a" stroke-width="1.8"/>
 <circle r="18.6" fill="none" stroke="#ffd24d" stroke-width="1.3" stroke-dasharray="1.3 2.6"/>
 <path d="M-3.4,-14.5 h6.8 v6.2 c0,2.4 8.8,4.4 8.8,13.2 c0,6.8 -4.8,11.2 -12.2,11.2 s-12.2,-4.4 -12.2,-11.2 c0,-8.8 8.8,-10.8 8.8,-13.2 z" fill="#1f8a70" stroke="#1d1b3a" stroke-width="1.4" stroke-linejoin="round"/>
 <path d="M-9.6,5.2 c1.6,-3.2 5.8,-4.2 9.6,-3.2 s7.6,0.4 9.6,3.2" fill="none" stroke="#9be3c9" stroke-width="1.3" stroke-linecap="round"/>
 <path d="M-8.6,6.6 c-0.6,2.4 -0.4,4.6 0.8,6.4" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" opacity=".75"/>
 <rect x="-4.2" y="-19.2" width="8.4" height="5.6" rx="1.4" fill="#c98b4b" stroke="#1d1b3a" stroke-width="1.2"/>
 <circle cx="0" cy="-9.2" r="2.3" fill="#d9334f" stroke="#1d1b3a" stroke-width="0.8"/>
 <circle cx="0.4" cy="7.4" r="4.7" fill="#fff4dc" stroke="#1d1b3a" stroke-width="1"/>
 <path d="M0.4,4.3 l1.0,2.2 2.4,0.3 -1.8,1.6 0.5,2.4 -2.1,-1.2 -2.1,1.2 0.5,-2.4 -1.8,-1.6 2.4,-0.3z" fill="#6b49c8"/>
</g>'''

def tokens():
    t=etree.parse(str(SRC/'jetons_page1_texte.svg')); r=t.getroot()
    # 1) retirer les 3 images de flacon d'origine (emballage commercial) et poser le flacon original
    gs=[c for c in r if c.tag==ns+'g' and (c.get('id') or '').startswith('g1-1-0')]
    print('groupes flacon (images) retirés :',len(gs))
    for g in gs: r.remove(g)
    for k,cx in enumerate((58,112,166)):
        r.append(etree.fromstring(FLACON.format(cx=cx,cy=268.7)))
    # 2) marqueur de manche : plus de « I » (le marqueur se déplace sur la piste de manches)
    for c in list(r):
        if c.tag==ns+'text' and txt(c)=='I':
            x=116.58; y=841.89-421.19  # position d'origine du « I »
            tri=etree.Element(ns+'path',{'d':f'M{x-4.2:.2f},{y-9.6:.2f} L{x+6.2:.2f},{y-1.6:.2f} L{x-4.2:.2f},{y+6.4:.2f} Z','fill':'#1d1b3a','stroke':'#1d1b3a','stroke-width':'1.2','stroke-linejoin':'round'})
            c.addnext(tri); r.remove(c)
    # 3) pied de page v0.5 retiré (le PDF d'impression pose le sien)
    for c in list(r):
        if c.tag==ns+'text' and txt(c).startswith('Jetons v0.5'): r.remove(c)
    # 4) libellé de la zone : "MARQUEUR DE MANCHE" inchangé
    t.write(str(OUT/'J1_jetons_page1.svg'),xml_declaration=True,encoding='utf-8')
    # flacon seul pour IA-1 (plateau, case 33)
    f=etree.fromstring('<svg xmlns="http://www.w3.org/2000/svg" viewBox="-24 -24 48 48" width="144" height="144">'+FLACON.replace('<g xmlns="http://www.w3.org/2000/svg" transform="translate({cx},{cy})">','<g>')[:]+'</svg>')
    etree.ElementTree(f).write('out/flacon_original.svg',xml_declaration=True,encoding='utf-8')

    t=etree.parse(str(SRC/'jetons_page2_texte.svg')); r=t.getroot()
    for c in list(r):
        if c.tag==ns+'text' and txt(c).startswith('Jetons v0.5'): r.remove(c)
    t.write(str(OUT/'J2_jetons_page2.svg'),xml_declaration=True,encoding='utf-8')
tokens()
