# Corrections des faces des cartes selon le contrat v0.6 (IA-2).
# Entrée : ../CARTE/...   Sortie : out/fronts/*.svg
import re, shutil, pathlib, copy
from lxml import etree
SVG='http://www.w3.org/2000/svg'; ns='{%s}'%SVG
SRC=pathlib.Path('../CARTE'); OUT=pathlib.Path('out/fronts'); OUT.mkdir(parents=True,exist_ok=True)

def txt(e): return ''.join(e.itertext()).strip()
def texts(root): return list(root.iter(ns+'text'))
def set_tspan(e,s,x=None,anchor=None):
    """remplace le texte d'une ligne ; supprime les positions glyphe par glyphe d'origine"""
    ts=e[0]
    for c in list(e)[1:]: e.remove(c)
    ts.text=s
    for c in list(ts): ts.remove(c)
    if x is not None: ts.set('x',str(x))
    elif ' ' in ts.get('x','').strip():
        ts.set('x',ts.get('x').split()[0])
    if anchor: e.set('text-anchor',anchor)
def find(root,start,exact=False):
    r=[e for e in texts(root) if (txt(e)==start if exact else txt(e).startswith(start))]
    assert r, 'introuvable: '+start
    return r[0]

def footer(root,new):
    for e in texts(root):
        if txt(e).startswith('Cartes v0.5') or txt(e).startswith('Jetons v0.5'):
            set_tspan(e,new, anchor=e.get('text-anchor'))
            return
    print('  (pas de pied de page)')

# ---------- page 1 : héros + Rediffusion + carte du tronc ----------
def page1():
    f=SRC/'carte-page-1/cartes_v0_5_page1_texte.svg'
    t=etree.parse(str(f)); r=t.getroot()
    # Maître : respecte la Mémoire (contrat D4/D6)
    e=find(r,'autre de ta main.'); set_tspan(e,'autre de ta main (sauf celle d’avant).',x=476.64,anchor='middle')
    # Rediffusion (D10)
    e0=find(r,'Tu dois rejouer la même carte action')
    allt=texts(r); i0=allt.index(e0)
    new=['Cette manche seulement, tu dois','rejouer la même carte que la manche','précédente (première manche ou carte','bloquée ? Joue celle que tu veux).','Les Scénaristes le savent déjà.']
    for k,s in enumerate(new):
        set_tspan(allt[i0+k],s,x=297.64,anchor='middle')
    e=find(r,'Dure jusqu’au prochain Genre'); set_tspan(e,'Dure une seule manche.',x=245.24,anchor='start')
    # Carte du tronc : retirer les éléments 150..183 (étapes) et les redessiner
    kids=list(r)
    i_first=[i for i,c in enumerate(kids) if c.tag==ns+'path' and c.get('fill')=='#d9334f'][0]
    i_foot=[i for i,c in enumerate(kids) if c.tag==ns+'text' and txt(c).startswith('Cartes v0.5')][0]
    for c in kids[i_first:i_foot]: r.remove(c)
    steps=[
     'Pose ton pion sur la case de ta carte Héros, puis une porte en secret : ROUGE avance de 3, BLEUE donne 1 Armure.',
     'Chaque manche, joue en secret COUP, GARDE ou RUSE. Coup bat Ruse, Ruse bat Garde, Garde bat Coup. Jamais la même carte que la manche d’avant.',
     'Duels : tu affrontes ton voisin de gauche, et celui de droite t’affronte : même carte, deux duels. Le perdant recule de 3.',
     'Tout le monde lance le dé et avance.',
     'Celui qui tient la Plume devine la carte d’un autre : voir le parchemin.',
     'Atteins ou dépasse la case 33 avec 1 Relique (ou 2 Armures à défausser) et tu gagnes. Le reste est écrit sur les cartes.',
    ]
    from PIL import ImageFont
    font=ImageFont.truetype('/usr/share/fonts/truetype/crosextra/Carlito-Regular.ttf',100)
    FS=8.0; W=134.0; LH=9.1; GAP=7.5
    def wrap(s):
        words=s.split(); lines=[]; cur=''
        for w in words:
            tr=(cur+' '+w).strip()
            if font.getlength(tr)*FS/100<=W: cur=tr
            else: lines.append(cur); cur=w
        lines.append(cur); return lines
    y=246.445   # ligne de base de la 1re ligne (repère PDF positif)
    g=etree.SubElement(r,ns+'g'); g.set('id','tronc_v06')
    # la page porte une transformation de repère PDF (y vers le haut) : on la reproduit
    for n,s in enumerate(steps,1):
        ls=wrap(s)
        cy=y-2.8
        c1=etree.SubElement(g,ns+'circle',{'cx':'407.14','cy':f'{841.89-cy-0.0:.3f}','r':'6.2','fill':'#d9334f','stroke':'#1d1b3a','stroke-width':'0.6'})
        d=etree.SubElement(g,ns+'text',{'x':'407.14','y':f'{841.89-cy+2.9:.3f}','text-anchor':'middle','font-family':'Carlito','font-weight':'bold','font-size':'8','fill':'#ffffff'}); d.text=str(n)
        for l in ls:
            tt=etree.SubElement(g,ns+'text',{'x':'416.14','y':f'{841.89-y:.3f}','font-family':'Carlito','font-size':str(FS),'fill':'#1d1b3a'}); tt.text=l
            y-=LH
        y-=GAP
        last_y=y
    print('  tronc : dernière ligne à y_pdf =',round(y+GAP+LH,1),'(bas de la carte ≈ 47)')
    # le pied de page d'origine est supprimé : le PDF d'impression pose le sien
    for c in list(r):
        if c.tag==ns+'text' and txt(c).startswith('Cartes v0.5'): r.remove(c)
    t.write(str(OUT/'F01_heros_rediffusion_tronc.svg'),xml_declaration=True,encoding='utf-8')

# ---------- pages-2 ----------
def pages2():
    for n in range(1,9):
        f=SRC/f'cartes_v0_5_pages-2/cartes_v0_5_page_{n}.svg'
        t=etree.parse(str(f)); r=t.getroot()
        if n==2:
            set_tspan(find(r,'Genres A puis B'),'Genres en alternance : A, B, A, B…')
            e=find(r,'Un Genre après chaque 3e'); set_tspan(e,'Un Genre après chaque 3e manche.',x=415.14,anchor='start')
        if n==6:
            allt=texts(r); i=allt.index(find(r,'Le dernier du parcours est'))
            seg=allt[i:i+6]
            new=['Le dernier du parcours est « mort » : on ne','peut pas le viser, et s’il tient la Plume il','n’écrit pas de prophétie. Pas de recul de','duel pour lui. Dès qu’il n’est plus dernier,','il revient avec un monologue de 10 secondes','(+2 cases si la table applaudit). Égalité pour','la dernière place : personne n’est mort.']
            assert len(seg)==6
            for e,s in zip(seg,new[:6]): set_tspan(e,s)
            # 7e ligne : on clone la dernière
            e7=copy.deepcopy(seg[-1]); seg[-1].addnext(e7)
            y=float(seg[-1][0].get('y'))+ (float(seg[-1][0].get('y'))-float(seg[-2][0].get('y')))
            e7[0].set('y',f'{y:.3f}'); set_tspan(e7,new[6])
            print('  fausse mort : 7e ligne y =',round(y,1))
        for e in texts(r):
            if txt(e).startswith('Cartes v0.5'): e.getparent().remove(e); break
        names={1:'F09_evenements_acte1_aventure',2:'F11_evenements_acte2_table',3:'F13_evenements_acte3',4:'F15_rebondissements_R01-R09',5:'F17_rebondissements_R10-R16',6:'F19_genres',7:'F21_dossier_gerard',8:'F23_proces_verbal'}
        t.write(str(OUT/(names[n]+'.svg')),xml_declaration=True,encoding='utf-8')

# ---------- actions (pages 2,3,4 de carte-page-1) et parchemins (page 5) ----------
def autres():
    for n,name in [(2,'F03_actions_hurleur_rival_maitre'),(3,'F05_actions_artichaut_traitre_comique'),(4,'F07_actions_stratege'),(5,'FP_parchemins')]:
        t=etree.parse(str(SRC/f'carte-page-1/cartes_v0_5_page{n}_texte.svg')); r=t.getroot()
        for e in texts(r):
            if txt(e).startswith(('Cartes v0.5','Parchemins v0.5')): e.getparent().remove(e)
        t.write(str(OUT/(name+'.svg')),xml_declaration=True,encoding='utf-8')

page1(); pages2(); autres()
print(sorted(p.name for p in OUT.iterdir()))
