import sys, pathlib
from playwright.sync_api import sync_playwright
out=pathlib.Path(sys.argv[1]).resolve(); out.mkdir(exist_ok=True,parents=True)
scale=float(sys.argv[2])
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':595,'height':842},device_scale_factor=scale)
    for f in sys.argv[3:]:
        f=pathlib.Path(f).resolve()
        h=out/(f.stem+'.html')
        h.write_text(f'<html><body style="margin:0;background:#fff"><img src="file://{f}" style="width:595px;height:842px;display:block"></body></html>')
        pg.goto('file://'+str(h)); pg.wait_for_timeout(500)
        pg.screenshot(path=str(out/(f.stem+'.png')))
        h.unlink()
    b.close()
