# PDF d'impression v0.6 : gouttière 3 mm, marge de couleur 1,5 mm, repères de coupe, polices incorporées.
import pathlib, re, subprocess
from lxml import etree
from PIL import Image
import numpy as np
from playwright.sync_api import sync_playwright
ns='{http://www.w3.org/2000/svg}'
X0,Y0,W,H=29.14,47.445,179,249; G=8.5; B=4.25
OX=(595.28-(3*W+2*G))/2; OY=(841.89-(3*H+2*G))/2
F=pathlib.Path('out/fronts'); K=pathlib.Path('out/backs'); R=pathlib.Path('../chk2'); P=pathlib.Path('out/print'); P.mkdir(exist_ok=True,parents=True)
pairs=[('F01_heros_rediffusion_tronc','B02_dos_heros','Héros + Rediffusion + carte du tronc'),
('F03_actions_hurleur_rival_maitre','B04_dos_actions','Cartes action 1/3'),
('F05_actions_artichaut_traitre_comique','B06_dos_actions','Cartes action 2/3'),
('F07_actions_stratege','B08_dos_actions','Cartes action 3/3 (Stratège)'),
('F09_evenements_acte1_aventure','B10_dos_evenements_acte1','Événements Acte I + Aventure'),
('F11_evenements_acte2_table','B12_dos_evenements_acte2','Événements Acte II + La Table'),
('F13_evenements_acte3','B14_dos_evenements_acte3','Événements Acte III'),
('F15_rebondissements_R01-R09','B16_dos_rebondissements_R01-R09','Rebondissements R01 à R09'),
('F17_rebondissements_R10-R16','B18_dos_rebondissements_R10-R16','Rebondissements R10 à R16'),
('F19_genres','B20_dos_genres','Genres'),
('F21_dossier_gerard','B22_dos_dossier_gerard','Dossier Gérard (facultatif)'),
('F23_proces_verbal','B24_dos_proces_verbal','Procès-verbal (Dossier)')]
def px(im,x,y): return tuple(int(v) for v in im[int(y),int(x)][:3])
def hexc(c): return '#%02x%02x%02x'%c
def occ(png):
    im=np.array(Image.open(png).convert('RGB')).astype(int); o=[]
    for r in range(3):
        o.append([int((np.abs(im[int(Y0+r*H+H/2)-40:int(Y0+r*H+H/2)+40,int(X0+c*W+W/2)-40:int(X0+c*W+W/2)+40]-255).sum(axis=2)>40).mean()>0.5) for c in range(3)])
    return o
def load(path):
    t=etree.parse(str(path)); r=t.getroot()
    NS={None:'http://www.w3.org/2000/svg'}; defs=etree.Element(ns+'defs',nsmap=NS); body=etree.Element(ns+'g',id='src',nsmap=NS)
    for c in list(r):
        tag=c.tag.replace(ns,'')
        if tag=='defs':
            for d in c: defs.append(d)
        elif tag in('metadata',) or 'namedview' in c.tag: continue
        else: body.append(c)
    return defs,body
def serial(e): return etree.tostring(e).decode().replace('xmlns:ns0','xmlns:ns0')
def page(path,label,cells,kind):
    defs,body=load(path)
    im=np.array(Image.open(R/(path.stem+'.png')).convert('RGB')).astype(int)
    out=['<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" width="595.28pt" height="841.89pt" viewBox="0 0 595.28 841.89">','<rect width="595.28" height="841.89" fill="#fff"/>','<defs>']
    out+= [serial(d) for d in defs]+[serial(body),'</defs>']
    for r,c in cells:
        nx=OX+c*(W+G); ny=OY+r*(H+G); sx=X0+c*W; sy=Y0+r*H
        if kind=='F':
            body_c=hexc(px(im,sx+6,sy+H*0.6)); top_c=hexc(px(im,sx+14,sy+4))
            hh=4
            while hh<70 and sum(abs(a-b) for a,b in zip(px(im,sx+14,sy+hh),px(im,sx+14,sy+4)))<60: hh+=1
            out.append(f'<rect x="{nx-B:.2f}" y="{ny-B:.2f}" width="{W+2*B}" height="{H+2*B}" fill="{body_c}"/>')
            out.append(f'<rect x="{nx-B:.2f}" y="{ny-B:.2f}" width="{W+2*B}" height="{hh+B}" fill="{top_c}"/>')
        else:
            out.append(f'<rect x="{nx-B:.2f}" y="{ny-B:.2f}" width="{W+2*B}" height="{H+2*B}" fill="{hexc(px(im,sx+2,sy+H/2))}"/>')
        out.append(f'<svg x="{nx:.2f}" y="{ny:.2f}" width="{W}" height="{H}" viewBox="{sx} {sy} {W} {H}" overflow="hidden"><use xlink:href="#src"/></svg>')
    # repères de coupe dans les marges
    xs=[OX+c*(W+G)+d for c in range(3) for d in (0,W)]; ys=[OY+r*(H+G)+d for r in range(3) for d in (0,H)]
    m=[]
    for x in xs: m+= [f'M{x:.2f},{OY-14:.2f}V{OY-5:.2f}',f'M{x:.2f},{841.89-OY+5:.2f}V{841.89-OY+14:.2f}']
    for y in ys: m+= [f'M{OX-14:.2f},{y:.2f}H{OX-5:.2f}',f'M{595.28-OX+5:.2f},{y:.2f}H{595.28-OX+14:.2f}']
    out.append(f'<path d="{"".join(m)}" stroke="#000" stroke-width="0.35" fill="none"/>')
    out.append(f'<text x="297.64" y="826" text-anchor="middle" font-family="Carlito" font-size="7" fill="#444">{label}</text>')
    out.append('</svg>'); return '\n'.join(out)
def simple(path,label):
    t=etree.parse(str(path)); r=t.getroot(); s=etree.tostring(r).decode()
    s=s.replace('</svg>',f'<text x="297.64" y="832" text-anchor="middle" font-family="Carlito" font-size="7" fill="#444">{label}</text></svg>')
    return s
jobs=[]
for i,(f,b,name) in enumerate(pairs):
    n=1+2*i; fo=occ(R/(f+'.png')); cells=[(r,c) for r in range(3) for c in range(3) if fo[r][c]]
    bcells=[(r,2-c) for r,c in cells]
    (P/f'p{n:02d}.svg').write_text(encoding='utf-8',data=page(F/(f+'.svg'),f'C’ÉTAIT ÉCRIT · cartes v0.6 · p{n:02d} RECTO · {name} · imprimer à 100 %, recto-verso, retourner sur le grand côté',cells,'F'))
    (P/f'p{n+1:02d}.svg').write_text(encoding='utf-8',data=page(K/(b+'.svg'),f'C’ÉTAIT ÉCRIT · cartes v0.6 · p{n+1:02d} DOS · {name}',bcells,'B'))
    jobs+= [f'p{n:02d}',f'p{n+1:02d}']
(P/'p25.svg').write_text(encoding='utf-8',data=simple(F/'J1_jetons_page1.svg','C’ÉTAIT ÉCRIT · jetons v0.6 · page 1/2 · 100 %, recto seul, papier épais'))
(P/'p26.svg').write_text(encoding='utf-8',data=simple(F/'J2_jetons_page2.svg','C’ÉTAIT ÉCRIT · jetons v0.6 · page 2/2 · 100 %, recto seul, papier épais'))
(P/'p27.svg').write_text(encoding='utf-8',data=simple(F/'FP_parchemins.svg','C’ÉTAIT ÉCRIT · parchemins de prophétie · photocopier autant que nécessaire · 100 %, recto seul'))
jobs+=['p25','p26','p27']
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page()
    for j in jobs:
        s=(P/f'{j}.svg').read_text(encoding='utf-8')
        s=re.sub(r'^<\?xml[^>]*\?>','',s)
        (P/f'{j}.html').write_text(encoding='utf-8',data='<html><head><meta charset="utf-8"><style>@page{size:210mm 297mm;margin:0}html,body{margin:0}svg{display:block;width:210mm;height:297mm}</style></head><body>'+s+'</body></html>')
        pg.goto('file://'+str((P/f'{j}.html').resolve())); pg.wait_for_timeout(300)
        pg.pdf(path=str(P/f'{j}.pdf'),width='210mm',height='297mm',print_background=True,margin=dict(top='0',bottom='0',left='0',right='0'))
    b.close()
subprocess.run(['qpdf','--empty','--pages']+[str(P/f'{j}.pdf') for j in jobs]+['--','out/CARTES_v0_6_impression.pdf'],check=True)
print('ok')
